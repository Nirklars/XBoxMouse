XBox 360 Controller to Mouse Simulator
Written by Nicklas
http://nirklars.wordpress.com/xboxmouse

Compiled using AutoHotkey 1.0.48.05
http://www.autohotkey.com/board/topic/86134-autohotkey-10-classic-and-basic-versions/
Edit compile.bat to point to your AutoHotkey install directory

Best Regards
Nick